package com.system.po;

/**
 * College扩展类
 */
public class CollegeCustom extends College {



}
